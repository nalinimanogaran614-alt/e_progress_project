# =========================================================
# E-PROGRESS CARD - DATABASE CONFIGURATION
# =========================================================

DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = ""
DB_NAME = "e_progress_card"
DB_PORT = 3306